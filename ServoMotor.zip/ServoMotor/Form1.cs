﻿using System;
using System.IO.Ports;
using System.Windows.Forms;

namespace ServoMotor
{
    public partial class Form1 : Form
    {
        // Declarar el puerto serial
        private SerialPort serialPort;

        public Form1()
        {
            InitializeComponent();
            // Inicializar el puerto serial
            serialPort = new SerialPort();
            serialPort.BaudRate = 9600; // Configurar la velocidad de transmisión

            // Configurar el rango y los incrementos de TrackBar
            trackBar1.Minimum = 0;
            trackBar1.Maximum = 180;
            trackBar1.TickFrequency = 5; // Saltos de 5 en 5 grados
            trackBar1.Value = 0;

            // Mostrar el valor inicial en el Label
            label1.Text = "Ángulo: " + trackBar1.Value.ToString() + "°";
        }

        // Método para abrir el puerto serial cuando se hace clic en el botón de conexión
        private void button1_Click(object sender, EventArgs e)
        {
            if (!serialPort.IsOpen)
            {
                try
                {
                    serialPort.PortName = "COM3"; // Cambia "COM3" por el puerto correspondiente al Arduino
                    serialPort.Open();
                    MessageBox.Show("Conexión establecida");
                    button1.Text = "Desconectar";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al abrir el puerto serial: " + ex.Message);
                }
            }
            else
            {
                // Cerrar el puerto si ya está abierto
                serialPort.Close();
                MessageBox.Show("Conexión cerrada");
                button1.Text = "Conectar";
            }
        }

        // Método para enviar el ángulo al Arduino cuando el usuario cambia el valor del TrackBar
        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            int angle = (trackBar1.Value / 5) * 5; // Ajusta el valor a múltiplos de 5
            label1.Text = "Ángulo: " + angle.ToString() + "°";

            // Verificar que el puerto esté abierto antes de enviar el dato
            if (serialPort.IsOpen)
            {
                try
                {
                    serialPort.WriteLine(angle.ToString()); // Enviar el ángulo al Arduino
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al enviar datos: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("El puerto serial no está abierto.");
            }
        }
    }
}
